﻿using System;
using System.Collections.Generic;
using System.Text;
using Medcilia.Clinic.Infrastructure.Domain;

namespace Medcilia.Clinic.Infrastructure.Repository.Settings
{
    public interface ISettingsRepository : IBaseRepository<Domain.Settings>
    {

    }
}
