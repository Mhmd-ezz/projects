﻿namespace Medcilia.Clinic.Infrastructure.Services.Security
{
    public class Policies
    {
        public static readonly string ADMIN = "admin";
        public static readonly string NOT_FOR_CLIENTS = "NotForClients";
    }
}
