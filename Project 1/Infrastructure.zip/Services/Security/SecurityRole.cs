﻿using System;

namespace Medcilia.Clinic.Infrastructure.Services.Security
{
    public class SecurityRole
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string DisplayName { get; set; }
    }
}
