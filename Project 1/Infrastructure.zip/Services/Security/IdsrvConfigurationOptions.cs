﻿namespace Medcilia.Clinic.Infrastructure.Services.Security
{
    public class IdsrvConfigurationOptions
    {
        public string SecurityServerUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
    }
}
