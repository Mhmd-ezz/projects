﻿namespace Medcilia.Clinic.Infrastructure.Services.Security
{
    /// <summary>
    /// Case sensitive values
    /// </summary>
    public class Roles
    {
        public static readonly string ADMIN = "admin";
        public static readonly string SERVICEPROVIDER = "serviceProvider";
    }
}
