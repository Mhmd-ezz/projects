﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Medcilia.Clinic.WebApi.Models
{
    public class TupleModel
    {
        public string Name { get; set; }
        public string Key { get; set; }
        public string Group { get; set; }
    }
}
