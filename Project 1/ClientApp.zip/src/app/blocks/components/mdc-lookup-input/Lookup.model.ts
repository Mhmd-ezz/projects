export interface ILookupView {
    id?: any
    text: string
    value?: string
    group: string
}