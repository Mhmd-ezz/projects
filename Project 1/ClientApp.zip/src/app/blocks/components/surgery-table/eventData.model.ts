export interface outputDataEvent{     
    data : any
}