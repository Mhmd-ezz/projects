import { AppointmentDialogComponent } from './appointment-dialog.component';
import { AppointmentDialogModule } from './appointment-dialog.module';
import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import {  MatBottomSheet } from '@angular/material/bottom-sheet';
import { AppointmentBase } from 'app/blocks/graphql/generated/bases';
import { ConfirmActionSheetArgs } from 'app/blocks/interface/confirm-action-sheet-args';
import { ConfirmActionSheetComponent } from '../confirm-action-sheet/confirm-action-sheet.component';

@Injectable({
    providedIn: AppointmentDialogModule
})
export class AppointmentDialogService {

    constructor(
        public dialog: MatDialog,
        private _bottomSheet: MatBottomSheet,

    ) { }

    openDialog(data: AppointmentBase, ) {
        const dialogRef = this.dialog.open(AppointmentDialogComponent, {
            disableClose: true,
            height: '90vh',
            // minWidth: '320px',
            data: data,
        });

        // @ Exit On escape keydown
        dialogRef.keydownEvents().subscribe((keyboardEvent: KeyboardEvent) => {
            if (keyboardEvent && keyboardEvent.which === 27) {
                this.confirmDialogClose(dialogRef);
            }
        });

        return dialogRef;
    }

    /**
    * @Description Confirm if appointment dialog should be closed
    * 
    * @private
    * @param {MatDialogRef<any, any>} dialog 
    * 
    * @memberOf AppScheduleComponent
    */
    private confirmDialogClose(dialog: MatDialogRef<any, any>) {

        const args: ConfirmActionSheetArgs = {
            yes: 'Exit and discard changes',
            no: 'Don\'t exit'
        };
        const Confirmsheet = this._bottomSheet.open(ConfirmActionSheetComponent, {
            data: args,
            disableClose: true
        });

        Confirmsheet.afterDismissed().subscribe(result => {
            if (result) {
                dialog.close(null);
            }
        });
    }

}
