export interface outputDataEvent{
    modelName : string,
    data : any
}