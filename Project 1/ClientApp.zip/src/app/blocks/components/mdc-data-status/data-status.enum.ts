export enum DataStatusEnum {
    local = 'local',
    server = 'server',
    serverNotReachable='serverNotReachable'
    // saving = 'saving',
    // invalid = 'invalid',
    // pending = 'pending',
    // savedLocally = 'savedLocally',
    // validationError = 'validationError',
    // duplicates = 'duplicates',
}
