export enum EventActionTypesEnum {
  new = 'new',
  edit = 'edit',
  delete = 'delete',
}
