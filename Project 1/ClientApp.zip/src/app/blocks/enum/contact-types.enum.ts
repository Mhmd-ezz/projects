export enum ContactTypesEnum {
    patient = 'patient',
    contact = 'contact',
    agent = 'agent',
}
