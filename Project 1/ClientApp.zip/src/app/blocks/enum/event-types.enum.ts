export enum EventTypesEnum {
  operation = 'Operation',
  visit = 'Visit',
  floor = 'Floor',
  conference = 'Conference',
  event = 'Event',
}
