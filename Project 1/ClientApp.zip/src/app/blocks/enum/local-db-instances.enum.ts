export enum LocalDbInstances {
    Medcilia = 'Medcilia',
    MedciliaData = 'MedciliaData',
    MedciliaMedia = 'MedciliaMedia',
}
