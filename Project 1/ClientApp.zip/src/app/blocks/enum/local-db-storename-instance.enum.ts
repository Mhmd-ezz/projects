export enum LocalDbStorenameInstanceEnum {
    appointmentsSettings = 'appointmentsSettings',
    tenant = 'tenant',
    patientsSettings = 'patientsSettings',
    filesQueue = 'filesQueue',
    offlineQueue = 'offlineQueue',
}
