export enum subscriptionEventEnum {
    appointment_created = "appointment_created",
    appointment_updated = "appointment_updated",
    appointment_status_changed = "appointment_status_changed",
    ticket_created = "ticket_created",
    ticket_updated = "ticket_updated",
}
