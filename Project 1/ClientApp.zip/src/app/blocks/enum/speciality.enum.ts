export enum SpecialityEnum {
    general = "general",
    cardiology = "cardiology"
}
