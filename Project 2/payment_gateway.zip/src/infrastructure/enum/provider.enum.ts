export enum ProviderEnum {
    stripe = "stripe",
}
