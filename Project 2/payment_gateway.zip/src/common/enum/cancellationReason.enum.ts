export enum CancellationReasonEnum {
    abandoned = 'abandoned',
    duplicate = 'duplicate',
    fraudulent = 'fraudulent',
    requested_by_customer = 'requested_by_customer'
}